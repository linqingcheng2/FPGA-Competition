from pathlib import Path
import sys,json,hashlib,os,subprocess
OUT=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(OUT/'measurement_console_route_opt'))
from console import EngineeringConsole,PROJECT
from render_scene import scene
assert (PROJECT/'results/simulation/tone8k/metrics.csv').is_file(), 'Complete the current tone8k simulation before UI loading checks'
app=EngineeringConsole();app.geometry('1440x900');app.update();app.withdraw()
assert app.session is None and not app.connected
assert app.version_id==500 and app.project==PROJECT
assert set(app.tabs)=={'完整频谱','瀑布图','I/Q 波形','测量历史'} or len(app.tabs)>=3
assert app.parameters()['n'] in (8192,16384)
for key in ('connect','capture','preview'):assert key in app.action_buttons
assert str(PROJECT).endswith('competition_project_route_opt')
assert (PROJECT/'host/analysis.py').read_text(encoding='utf-8').find('FS = 500_000_000')>=0
# Exercise the existing simulation load action with the new per-case record.
from unittest.mock import patch
with patch('app.filedialog.askopenfilename',return_value=str(PROJECT/'results/simulation/tone8k/metrics.csv')):
    app.open_simulation()
assert app.metric['source']=='simulation' and app.metric['fs']==500000000 and len(app.power)==8192
app.deiconify();app.update();scene(app,OUT/'UI布线优化预览.png');app.withdraw()
subprocess.run([sys.executable,'-E',str(OUT/'measurement_console_route_opt/run_125_adapter.py'),'--check'],check=True)
paths=list((OUT/'measurement_console_route_opt').glob('*.py'))+list((OUT/'measurement_atelier_route_opt').glob('*.py'))+[Path(__file__)]
(PROJECT/'results/ui_verification.json').write_text(json.dumps(dict(passed=True,title=app.title(),selected_sample_msps=500,project=str(PROJECT),auto_program=False,tabs=list(app.tabs),layout_source='original_layout_theme_plotting_widgets',source_sha256={os.path.relpath(p,PROJECT).replace(chr(92),'/'):hashlib.sha256(p.read_bytes()).hexdigest() for p in paths}),ensure_ascii=False,indent=2),encoding='utf-8')
app.destroy();print('INDEPENDENT_UI_500_PASS')
